<?php /* /home/mbrauna/Documents/Quack/Quack/QuackCliente/resources/views/layouts/quackintro.blade.php */ ?>
<!DOCTYPE html>
<html>
    <head>
        <!-- Zona para tratamento dinâmico do título -->
        <title><?php echo e(config('app.name', 'Quack!')); ?></title>
        <!-- Zona para tratamento dinâmico do título -->

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <!-- CSRF Token -->

        <!-- Configurações da página -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- Configurações da página -->

        <!-- Configurações para as descrições site -->
        <meta name="author"   content="MBrauna - Quack!">
        <meta name="keywords" content="Inteligência artificial, roteirização, mapa, detecção facial, Rede neural, deep learning, machine learning">
        <!-- Configurações para as descrições site -->

        <!-- CSS fixo -->
        <link rel="stylesheet" type="text/css" href="Quack/quack.css">
        <!-- CSS fixo -->

        <!-- JS fixo -->
        <script type="text/javascript" src="Quack/quack.js"></script>
        <!-- JS fixo -->

        <!-- CSS dinâmico -->
        <?php echo $__env->yieldContent('estilo_dinamico'); ?>
        <!-- CSS dinâmico -->
    </head>
    <body class="quack-site" id="topo">
        
    </body> <!-- <body class="quack-site" id="topo"> -->
</html>