<?php /* /home/mbrauna/Documents/Quack/Quack/QuackCliente/vendor/binarytorch/larecipe/src/../resources/views/docs.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid pl-0 documentation is-<?php echo e(config('larecipe.ui.code')); ?>">
	<div class="row">
		<div class="col-12 col-md-3 sidebar <?php echo e(config('larecipe.ui.theme') == 'dark' ? 'is-dark' : ''); ?>" 
			:class="[{'is-hidden': ! sidebar}, theme]">
			<?php echo $index; ?>

		</div>
		
		<div class="col-12 col-md-9 article" :class="{'expanded': ! sidebar}">
			<?php echo $content; ?>

			<?php echo $__env->make('larecipe::partials.plugins.forum', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('larecipe::default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>