<?php /* /home/mbrauna/Documents/Quack/Quack/QuackCliente/vendor/binarytorch/larecipe/src/../resources/views/default.blade.php */ ?>
<!doctype html>
<html>
    <head>
        
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title><?php echo e(isset($title) ? $title . ' | ' : null); ?><?php echo e(config('app.name')); ?></title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        
        <meta name="author" content="<?php echo e(config('larecipe.seo.author')); ?>">
        <meta name="description" content="<?php echo e(config('larecipe.seo.description')); ?>">
        <meta name="keywords" content="<?php echo e(config('larecipe.seo.keywords')); ?>">
        <meta name="twitter:card" value="summary">
        <?php if(isset($canonical) && $canonical): ?>
            <link rel="canonical" href="<?php echo e(url($canonical)); ?>" />
        <?php endif; ?>
        <?php if($openGraph = config('larecipe.seo.og')): ?>
            <?php $__currentLoopData = $openGraph; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($value): ?>
                    <meta property="og:<?php echo e($key); ?>" content="<?php echo e($value); ?>" />
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        
        <link rel="stylesheet" href="<?php echo e(larecipe_assets('css/app.css')); ?>">

        
        <script type="text/javascript">
            if(localStorage.getItem('larecipeSidebar') == null) {
                localStorage.setItem('larecipeSidebar', !! <?php echo e(config('larecipe.ui.show_side_bar') ?: 0); ?>);
            }
        </script>
        <script src="<?php echo e(larecipe_assets('js/app.js')); ?>" defer></script>

        
        <link rel="apple-touch-icon" href="<?php echo e(asset(config('larecipe.ui.fav'))); ?>">
        <link rel="shortcut icon" type="image/png" href="<?php echo e(asset(config('larecipe.ui.fav'))); ?>"/>
        
        
        <?php echo $__env->make('larecipe::partials.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        
        <?php if(!empty(config('larecipe.ui.additional_css'))): ?>
            <?php $__currentLoopData = config('larecipe.ui.additional_css'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $css): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <link rel="stylesheet" type="text/css" href="<?php echo e(asset($css) . '?id=' . \Illuminate\Support\Str::random(8)); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </head>
    <body>
        <div id="app" v-cloak>
            <?php echo $__env->make('larecipe::partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <?php echo $__env->make('larecipe::partials.plugins.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <?php echo $__env->yieldContent('content'); ?>

            <?php if(config('larecipe.ui.back_to_top')): ?>
                <larecipe-back-to-top></larecipe-back-to-top>
            <?php endif; ?>
        </div>

        
        <?php if(!empty(config('larecipe.ui.additional_js'))): ?>
            <?php $__currentLoopData = config('larecipe.ui.additional_js'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $js): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <script type="text/javascript" src="<?php echo e(asset($js) . '?id=' . \Illuminate\Support\Str::random(8)); ?>"></script>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        
        <?php if(config('larecipe.settings.ga_id')): ?>
            <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo e(config('larecipe.settings.ga_id')); ?>"></script>
            <script>
                window.dataLayer = window.dataLayer || [];
                function gtag(){dataLayer.push(arguments);}
                gtag('js', new Date());

                gtag('config', "<?php echo e(config('larecipe.settings.ga_id')); ?>");
            </script>
        <?php endif; ?>
        
    </body>
</html>
